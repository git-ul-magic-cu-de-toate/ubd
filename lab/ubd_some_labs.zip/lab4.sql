desc v$controlfile;
desc v$parameter;
select * from v$parameter where name='control_files';
